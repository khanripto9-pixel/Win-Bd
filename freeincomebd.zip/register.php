<?php
require_once __DIR__ . '/config.php';
if (!empty($_SESSION['user_id'])) { header('Location: dashboard.php'); exit; }
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $email = strtolower(trim($_POST['email'] ?? ''));
    $phone = trim($_POST['phone'] ?? '');
    $password = $_POST['password'] ?? '';
    if ($name === '' || !filter_var($email, FILTER_VALIDATE_EMAIL) || $phone === '' || strlen($password) < 6) {
        $error = 'সব তথ্য সঠিকভাবে পূরণ করুন এবং পাসওয়ার্ড কমপক্ষে ৬ অক্ষরের দিন।';
    } else {
        $auth = firebase_auth_request('accounts:signUp', ['email'=>$email,'password'=>$password,'returnSecureToken'=>true]);
        if ($auth['error']) {
            $error = 'এই ইমেইল দিয়ে নিবন্ধন করা যায়নি।';
        } else {
            $uid = $auth['data']['localId'];
            db_set('users/'.$uid, [
                'id'=>$uid,'name'=>$name,'email'=>$email,'phone'=>$phone,
                'password'=>'','balance'=>0,'status'=>'active','role'=>'user',
                'last_spin_at'=>null,'created_at'=>date('c')
            ]);
            $_SESSION['user_id'] = $uid;
            $_SESSION['role'] = 'user';
            header('Location: dashboard.php');
            exit;
        }
    }
}
?>
<!doctype html><html lang="bn"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title><?=APP_NAME?></title><link rel="stylesheet" href="assets/css/style.css"></head><body>
<div class="auth"><div class="card"><h1>ফ্রি ইনকাম বিডি 🇧🇩</h1><p>নতুন অ্যাকাউন্ট তৈরি করুন</p><?php if($error):?><div class="alert"><?=e($error)?></div><?php endif;?><form method="post">
<label>নাম<input name="name" required></label><label>ইমেইল<input type="email" name="email" required></label><label>মোবাইল নম্বর<input name="phone" required></label><label>পাসওয়ার্ড<input type="password" name="password" minlength="6" required></label><button>নিবন্ধন করুন</button></form><a href="login.php">আগে থেকেই অ্যাকাউন্ট আছে? লগইন করুন</a></div></div></body></html>