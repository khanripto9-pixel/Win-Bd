<?php
require_once __DIR__.'/includes/auth_check.php'; $message=''; $eligible=true; $next=0;
if(!empty($user['last_spin_at'])){$last=strtotime($user['last_spin_at']);$next=$last+86400;if(time()<$next)$eligible=false;}
if($_SERVER['REQUEST_METHOD']==='POST' && $eligible){
    $prize=weighted_prize(db_collection('spin_prizes'));
    if($prize){$amount=(float)$prize['data']['amount'];adjust_balance($_SESSION['user_id'],$amount);add_transaction($_SESSION['user_id'],'spin',$amount,'স্পিন বোনাস');db_update('users/'.$_SESSION['user_id'],['last_spin_at'=>date('c')]);$message='অভিনন্দন! আপনি ৳ '.number_format($amount,2).' বোনাস পেয়েছেন।';$eligible=false;$next=time()+86400;$user=db_get('users/'.$_SESSION['user_id']);}
    else $message='এই মুহূর্তে কোনো সক্রিয় পুরস্কার নেই।';
}
$pageTitle='দৈনিক স্পিন';include __DIR__.'/includes/header.php';?><div class="card center"><h1>দৈনিক ফ্রি স্পিন</h1><p>প্রতি ২৪ ঘণ্টায় একবার বিনামূল্যে স্পিন করা যাবে।</p><?php if($message):?><div class="success"><?=e($message)?></div><?php endif;?><?php if($eligible):?><form method="post"><button>স্পিন করুন</button></form><?php else:?><p>পরবর্তী স্পিনের সময়</p><div id="countdown" data-time="<?=e(date('c',$next))?>">অপেক্ষা করুন...</div><?php endif;?></div><?php include __DIR__.'/includes/footer.php';?>