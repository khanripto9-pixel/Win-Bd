<?php
require_once __DIR__.'/includes/auth_check.php'; $pageTitle='ড্যাশবোর্ড';
$tasks=db_collection('tasks'); $activeTasks=0; foreach($tasks as $t) if(($t['status']??'')==='active' && (int)($t['slots_used']??0)<(int)($t['slots']??0)) $activeTasks++;
include __DIR__.'/includes/header.php'; ?>
<section class="hero"><h1>স্বাগতম, <?=e($user['name'])?></h1><p>আপনার বর্তমান ব্যালেন্স</p><strong>৳ <?=number_format((float)($user['balance']??0),2)?></strong></section>
<div class="grid"><a class="tile" href="tasks.php"><b><?=$activeTasks?></b><span>সক্রিয় কাজ</span></a><a class="tile" href="spin.php"><b>🎁</b><span>দৈনিক স্পিন</span></a><a class="tile" href="wallet.php"><b>৳</b><span>ওয়ালেট</span></a><a class="tile" href="withdraw.php"><b>↗</b><span>উত্তোলন</span></a></div>
<?php include __DIR__.'/includes/popup.php'; include __DIR__.'/includes/footer.php'; ?>