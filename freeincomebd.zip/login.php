<?php
require_once __DIR__ . '/config.php';
if (!empty($_SESSION['user_id'])) { header('Location: dashboard.php'); exit; }
$error='';
if ($_SERVER['REQUEST_METHOD']==='POST') {
    $email=strtolower(trim($_POST['email']??'')); $password=$_POST['password']??'';
    $auth=firebase_auth_request('accounts:signInWithPassword',['email'=>$email,'password'=>$password,'returnSecureToken'=>true]);
    if ($auth['error']) $error='ইমেইল অথবা পাসওয়ার্ড সঠিক নয়।';
    else {
        $uid=$auth['data']['localId']; $user=db_get('users/'.$uid);
        if (!$user || ($user['status']??'active')!=='active') $error='আপনার অ্যাকাউন্ট বর্তমানে সক্রিয় নয়।';
        else { $_SESSION['user_id']=$uid; $_SESSION['role']=$user['role']??'user'; header('Location: dashboard.php'); exit; }
    }
}
?>
<!doctype html><html lang="bn"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title><?=APP_NAME?></title><link rel="stylesheet" href="assets/css/style.css"></head><body><div class="auth"><div class="card"><h1>ফ্রি ইনকাম বিডি 🇧🇩</h1><p>আপনার অ্যাকাউন্টে প্রবেশ করুন</p><?php if($error):?><div class="alert"><?=e($error)?></div><?php endif;?><form method="post"><label>ইমেইল<input type="email" name="email" required></label><label>পাসওয়ার্ড<input type="password" name="password" required></label><button>লগইন করুন</button></form><a href="register.php">নতুন অ্যাকাউন্ট তৈরি করুন</a></div></div></body></html>