<?php
require_once __DIR__ . '/../config.php';
$pageTitle = $pageTitle ?? APP_NAME;
?>
<!doctype html><html lang="bn"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1"><meta name="theme-color" content="#111827"><title><?=e($pageTitle)?></title><link rel="stylesheet" href="assets/css/style.css"></head><body><header class="top"><a href="dashboard.php">ফ্রি ইনকাম বিডি 🇧🇩</a><a href="logout.php">বের হন</a></header><main class="container">