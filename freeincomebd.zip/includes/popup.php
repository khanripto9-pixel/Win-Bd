<?php
$now=date('c'); $popups=db_collection('popups'); $active=null;
foreach($popups as $p){if(($p['status']??'')==='active' && ($p['start_at']??'')<=$now && ($p['end_at']??'')>=$now){$active=$p;break;}}
if($active): ?><div class="modal" id="popup"><div class="modal-box"><button class="close" onclick="document.getElementById('popup').remove()">×</button><h2><?=e($active['title']??'')?></h2><p><?=nl2br(e($active['message']??''))?></p><?php if(!empty($active['image'])):?><img src="<?=e($active['image'])?>" alt=""><?php endif;?></div></div><?php endif; ?>