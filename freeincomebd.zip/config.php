<?php
declare(strict_types=1);

session_start();

const FIREBASE_DATABASE_URL = 'https://YOUR_PROJECT_ID-default-rtdb.firebaseio.com';
const FIREBASE_API_KEY = 'YOUR_FIREBASE_WEB_API_KEY';
const FIREBASE_STORAGE_BUCKET = 'YOUR_PROJECT_ID.firebasestorage.app';
const APP_NAME = 'Free Income BD 🇧🇩';
const MIN_WITHDRAW = 50.00;
const MAX_UPLOAD_BYTES = 5242880;

function firebase_request(string $path, string $method = 'GET', ?array $data = null): array
{
    $url = rtrim(FIREBASE_DATABASE_URL, '/') . '/' . ltrim($path, '/') . '.json';
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_CUSTOMREQUEST => $method,
        CURLOPT_HTTPHEADER => ['Content-Type: application/json'],
        CURLOPT_TIMEOUT => 20
    ]);
    if ($data !== null) {
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data, JSON_UNESCAPED_UNICODE));
    }
    $response = curl_exec($ch);
    $status = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    if ($response === false || $status >= 400) {
        return ['error' => true, 'status' => $status, 'data' => null];
    }
    $decoded = json_decode($response, true);
    return ['error' => false, 'status' => $status, 'data' => $decoded];
}

function firebase_auth_request(string $endpoint, array $payload): array
{
    $url = 'https://identitytoolkit.googleapis.com/v1/' . $endpoint . '?key=' . urlencode(FIREBASE_API_KEY);
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_HTTPHEADER => ['Content-Type: application/json'],
        CURLOPT_POSTFIELDS => json_encode($payload, JSON_UNESCAPED_UNICODE),
        CURLOPT_TIMEOUT => 20
    ]);
    $response = curl_exec($ch);
    $status = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    $decoded = json_decode((string)$response, true);
    return ['error' => $status >= 400 || isset($decoded['error']), 'status' => $status, 'data' => $decoded];
}

function firebase_id(): string
{
    return bin2hex(random_bytes(12));
}

function db_get(string $path): mixed
{
    return firebase_request($path)['data'] ?? null;
}

function db_set(string $path, array $data): bool
{
    return !firebase_request($path, 'PUT', $data)['error'];
}

function db_update(string $path, array $data): bool
{
    return !firebase_request($path, 'PATCH', $data)['error'];
}

function db_delete(string $path): bool
{
    return !firebase_request($path, 'DELETE')['error'];
}

function db_push(string $path, array $data): ?string
{
    $result = firebase_request($path, 'POST', $data);
    return $result['data']['name'] ?? null;
}

function db_collection(string $path): array
{
    $data = db_get($path);
    return is_array($data) ? $data : [];
}

function e(?string $value): string
{
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

function current_user(): ?array
{
    if (empty($_SESSION['user_id'])) {
        return null;
    }
    return db_get('users/' . $_SESSION['user_id']);
}

function require_user(): array
{
    $user = current_user();
    if (!$user || ($user['status'] ?? 'active') !== 'active') {
        session_destroy();
        header('Location: login.php');
        exit;
    }
    return $user;
}

function require_admin(): array
{
    if (empty($_SESSION['admin_id'])) {
        header('Location: admin/admin_login.php');
        exit;
    }
    $admin = db_get('admins/' . $_SESSION['admin_id']);
    if (!$admin) {
        session_destroy();
        header('Location: admin/admin_login.php');
        exit;
    }
    return $admin;
}

function add_transaction(string $userId, string $type, float $amount, string $description): bool
{
    return db_push('wallet_transactions', [
        'user_id' => $userId,
        'type' => $type,
        'amount' => round($amount, 2),
        'description' => $description,
        'created_at' => date('c')
    ]) !== null;
}

function adjust_balance(string $userId, float $delta): bool
{
    $user = db_get('users/' . $userId);
    if (!$user) return false;
    $newBalance = round((float)($user['balance'] ?? 0) + $delta, 2);
    if ($newBalance < 0) return false;
    return db_update('users/' . $userId, ['balance' => $newBalance]);
}

function weighted_prize(array $prizes): ?array
{
    $active = [];
    $total = 0.0;
    foreach ($prizes as $id => $prize) {
        if (($prize['status'] ?? '') === 'active' && (float)($prize['probability_weight'] ?? 0) > 0) {
            $weight = (float)$prize['probability_weight'];
            $total += $weight;
            $active[] = ['id' => $id, 'data' => $prize, 'weight' => $weight];
        }
    }
    if ($total <= 0 || !$active) return null;
    $pick = random_int(1, max(1, (int)round($total * 10000))) / 10000;
    $sum = 0.0;
    foreach ($active as $item) {
        $sum += $item['weight'];
        if ($pick <= $sum) return $item;
    }
    return end($active);
}

function upload_proof(array $file): ?string
{
    if (($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) return null;
    if (($file['size'] ?? 0) > MAX_UPLOAD_BYTES) return null;
    $allowed = ['image/jpeg', 'image/png', 'image/webp'];
    $mime = mime_content_type($file['tmp_name']);
    if (!in_array($mime, $allowed, true)) return null;
    $dir = __DIR__ . '/uploads/proofs';
    if (!is_dir($dir)) mkdir($dir, 0755, true);
    $name = bin2hex(random_bytes(16)) . '.jpg';
    $target = $dir . '/' . $name;
    if (!move_uploaded_file($file['tmp_name'], $target)) return null;
    return 'uploads/proofs/' . $name;
}
?>