<?php
require_once __DIR__.'/includes/auth_check.php'; $taskId=$_GET['id']??$_POST['task_id']??''; $task=db_get('tasks/'.$taskId); if(!$task){header('Location: tasks.php');exit;}
$subs=db_collection('submissions'); foreach($subs as $s) if(($s['user_id']??'')===$_SESSION['user_id']&&($s['task_id']??'')===$taskId&&in_array(($s['status']??''),['pending','approved'],true)){header('Location: my_submissions.php');exit;}
$error='';
if($_SERVER['REQUEST_METHOD']==='POST'){
    $proofText=trim($_POST['proof_text']??''); $proofFile=upload_proof($_FILES['proof_file']??[]);
    if($proofText==='' && !$proofFile) $error='প্রমাণ হিসেবে লেখা, লিংক অথবা ছবি দিন।';
    else {
        db_push('submissions',['user_id'=>$_SESSION['user_id'],'task_id'=>$taskId,'proof_text'=>$proofText,'proof_file'=>$proofFile,'status'=>'pending','reject_reason'=>'','submitted_at'=>date('c'),'reviewed_at'=>null]);
        header('Location: my_submissions.php'); exit;
    }
}
include __DIR__.'/includes/header.php'; ?>
<div class="card"><h1>কাজের প্রমাণ জমা দিন</h1><?php if($error):?><div class="alert"><?=e($error)?></div><?php endif;?><form method="post" enctype="multipart/form-data"><input type="hidden" name="task_id" value="<?=e($taskId)?>"><label>প্রমাণের লেখা বা লিংক<textarea name="proof_text"></textarea></label><label>স্ক্রিনশট<input type="file" name="proof_file" accept="image/*"></label><button>জমা দিন</button></form></div><?php include __DIR__.'/includes/footer.php'; ?>